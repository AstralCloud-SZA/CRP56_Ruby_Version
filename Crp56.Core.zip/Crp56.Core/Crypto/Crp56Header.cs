﻿using System;
using System.IO;
using System.Text;

namespace Crp56.Core.Crypto
{
    #region CRP56 Header Class This class Represents the full file in memory.
    /// <summary>
    /// Represents the full CRP56 file header in memory.
    ///
    /// Binary layout (in order):
    /// ┌─────────────────────────────────────────────────┐
    /// │ OUTER HEADER                                    │
    /// │  [0..4]   Magic          : "CRP56" (5 bytes)   │
    /// │  [5]      Version        : byte (1 byte)        │
    /// │  [6]      KeySlotIndex   : byte (1 byte)        │
    /// │  [7]      Flags          : byte (1 byte)        │
    /// │               bit 0 = HMAC enabled              │
    /// │  [8..11]  KdfIterations  : int32 (4 bytes)      │
    /// │  [12]     CompressionMode: byte (1 byte)        │
    /// │               0x00 = None, 0x01 = Zstd, 0x02 = LZ4
    /// │  [13]     SaltLength     : byte (1 byte)        │
    /// │  [14..]   Salt           : SaltLength bytes     │
    /// ├─────────────────────────────────────────────────┤
    /// │ SHARD HEADER (immediately after outer header)  │
    /// │  TotalShards     : int32 (4 bytes)              │
    /// │  LastShardSize   : int32 (4 bytes)              │
    /// ├─────────────────────────────────────────────────┤
    /// │ SHARD DATA                                      │
    /// │  Per shard: [IV (16 bytes)] + [Ciphertext]      │
    /// ├─────────────────────────────────────────────────┤
    /// │ HMAC TAG (if Flags bit 0 = 1)                   │
    /// │  32 bytes (HMAC-SHA256 over everything above)   │
    /// └─────────────────────────────────────────────────┘
    /// </summary>
    /// 


    public class Crp56Header
    {
        #region Vars for the header fields

        // Outer header fields
        public byte Version { get; set; } = Crp56Constants.Version;
        public byte KeySlotIndex { get; set; }
        public byte Flags { get; set; }
        public int KdfIterations { get; set; }
        public byte CompressionMode { get; set; }
        public byte[] Salt { get; set; } = Array.Empty<byte>();

        // Shard header fields
        public int TotalShards { get; set; }
        public int LastShardSize { get; set; }

        #endregion

        #region HMAC ZONE 


        public const int HmacTagLength = 32; // HMAC-SHA256 produces a 32-byte tag

        public bool IsHmacEnabled
        {
            get => (Flags & 0x01) != 0;

            set
            {
                if (value)
                {
                    Flags |= 0x01;
                }
                else
                {
                    Flags &= unchecked((byte)~0x01);
                }
            }
        }
        #endregion


        #region SERIALIZATION ZONE

        // CALL THIS BEFORE WRITING THE SHARD DATA TO THE FILE

        public void WriteTo(BinaryWriter writer)
        {
            VAR_VALIDATOR(writer);

            //MAGIC
            writer.Write(Encoding.ASCII.GetBytes(Crp56Constants.Magic));

            //VERSION (1 byte)
            writer.Write(Version);

            //KEY SLOT INDEX (1 byte)
            writer.Write(KeySlotIndex);

            //FLAGS (1 byte)
            writer.Write(Flags);

            //KDF ITERATIONS (4 bytes)
            writer.Write(KdfIterations);

            //COMPRESSION MODE (1 byte)
            writer.Write(CompressionMode);

            //SALT LENGTH (1 byte) + salt bytes
            writer.Write((byte)Salt.Length);
            writer.Write(Salt);

            // SHARD HEADER
            writer.Write(TotalShards);
            writer.Write(LastShardSize);

        }


        private void VAR_VALIDATOR(BinaryWriter writer)
        {
            if (writer == null)
            {
                throw new ArgumentNullException(nameof(writer), "BinaryWriter cannot be null.");
            }

            if (Salt == null || Salt.Length == 0)
            {
                throw new InvalidOperationException("Salt must be set before writing the header.");

            }

            if (Salt.Length > byte.MaxValue)
            {
                throw new InvalidOperationException($"Salt length exceeds maximum of {byte.MaxValue} bytes.");
            }

        }
        #endregion

        #region DESERIALIZATION ZONE
        //  READS AND VALIDATES TEH FULL HEADER 

        public static Crp56Header ReadFrom(BinaryReader reader)
        {
            if (reader == null)
            {
                throw new ArgumentNullException(nameof(reader), "BinaryReader cannot be null.");
            }


            var header = new Crp56Header();

            // VALIDATE MAGIC
            byte[] magicBytes = reader.ReadBytes(Crp56Constants.Magic.Length);

            if (magicBytes.Length < Crp56Constants.Magic.Length)
            {
                throw new InvalidDataException("File is too short to contain valid CRP56 header.");
            }

            string magic = Encoding.ASCII.GetString(magicBytes);
            if (magic != Crp56Constants.Magic)
            {
                throw new InvalidDataException($"Not a CRP56 file. Expected magic '{Crp56Constants.Magic}', got '{magic}'.");
            }

            //VERSION

            header.Version = reader.ReadByte();

            if (header.Version != Crp56Constants.Version)
            {
                throw new InvalidDataException($"Unsupported CRP56 version. Expected {Crp56Constants.Version}, got {header.Version}.");
            }

            //KEY SLOT INDEX

            header.KeySlotIndex = reader.ReadByte();

            if (header.KeySlotIndex >= Crp56Constants.KeyPharaseSlots)
            {
                throw new InvalidDataException($"Invalid KeySlotIndex. Must be between 0 and {Crp56Constants.KeyPharaseSlots - 1}, got {header.KeySlotIndex}.");
            }

            //FLAGS
            header.Flags = reader.ReadByte();

            //KDF ITERATIONS
            header.KdfIterations = reader.ReadInt32();

            if (header.KdfIterations <= 0)
            {
                throw new InvalidDataException($"Invalid KDF iterations. Must be a positive integer, got {header.KdfIterations}.");
            }

            //COMPRESSION MODE
            header.CompressionMode = reader.ReadByte();

            if (header.CompressionMode != Crp56Constants.CompressionNone && header.CompressionMode != Crp56Constants.CompressionZstd && header.CompressionMode != Crp56Constants.CompressionLz4)
            {
                throw new InvalidDataException($"Invalid CompressionMode. Must be 0x00 (None), 0x01 (Zstd), or 0x02 (LZ4), got 0x{header.CompressionMode:X2}.");
            }

            //SALT LENGTH + SALT

            byte saltLength = reader.ReadByte();
            if (saltLength == 0)
            {
                throw new InvalidDataException("Salt length cannot be zero.");
            }

            header.Salt = reader.ReadBytes(saltLength);
            if (header.Salt.Length != saltLength)
            {
                throw new InvalidDataException($"File ended unexpectedly while reading salt. Expected {saltLength} bytes, got {header.Salt.Length} bytes.");
            }

            // SHARD HEADER
            header.TotalShards = reader.ReadInt32();
            if (header.TotalShards <= 0)
            {
                throw new InvalidDataException($"Invalid TotalShards. Must be a positive integer, got {header.TotalShards}.");
            }

            header.LastShardSize = reader.ReadInt32();
            if (header.LastShardSize <= 0)
            {
                throw new InvalidDataException("Invalid last shard plain size in header.");
            }

            return header;
        }

        #endregion

        #endregion
    }
}