﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Crp56.Core.Crypto
{

    /// <summary>
    /// Derives the AES encryption key and HMAC key from:
    ///   - A base key phrase (selected by slot index from KeyPhraseManager)
    ///   - The user's passphrase
    ///   - A random salt (stored in the CRP56 header)
    ///   - A KDF iteration count (stored in the CRP56 header)
    ///
    /// Uses PBKDF2 with HMAC-SHA256 via Rfc2898DeriveBytes.
    /// Produces 64 bytes total: first 32 = AES key, second 32 = HMAC key.
    /// </summary>
    /// 


    public static class KeyDerivation
    {
        // 64 Bytes are derived: 32 for AES key, 32 for HMAC key
        private const int TotalDerivedKeyBytes = Crp56Constants.AesKeySize * 2;

        /// <summary>
        ///Derives the AES key and HMAC key based on the provided parameters.
        /// The combination of the base key phrase, user passphrase, salt, and iteration count ensures that the derived keys are unique and secure for each file.
        /// </summary>
        /// 

        public static DerivedKeys Derive(string basePhrase,string userPassphrase, byte[] salt, int iterations)
        {
            if(string.IsNullOrEmpty(basePhrase)) throw new ArgumentException("Base phrase cannot be null or empty.", nameof(basePhrase));
            if(string.IsNullOrEmpty(userPassphrase)) throw new ArgumentException("User passphrase cannot be null or empty.", nameof(userPassphrase));
            if(salt == null || salt.Length == 0) throw new ArgumentException("Salt cannot be null or empty.", nameof(salt));
            if(iterations <= 0) throw new ArgumentOutOfRangeException(nameof(iterations), "Iterations must be a positive integer.");

            // Combine the base phrase and user passphrase to create the full password for key derivation.
            string combined = basePhrase + "|CRP56|" + userPassphrase;
            byte[] combinedBYTES = Encoding.UTF8.GetBytes(combined);

            byte[] derivedBytes = null;

            try
            {
                // PBKDF2 made via Rfc2898DeriveBytes with HMAC-SHA256, producing 64 bytes total.

                using var kdf = new Rfc2898DeriveBytes(combinedBYTES, salt, iterations, HashAlgorithmName.SHA256);

                derivedBytes = kdf.GetBytes(TotalDerivedKeyBytes);

                // Split the derived bytes into AES key and HMAC key.
                byte[] aesKey = new byte[Crp56Constants.AesKeySize];
                byte[] hmacKey = new byte[Crp56Constants.AesKeySize];

                Buffer.BlockCopy(derivedBytes, 0, aesKey, 0, Crp56Constants.AesKeySize);
                Buffer.BlockCopy(derivedBytes, Crp56Constants.AesKeySize, hmacKey, 0, Crp56Constants.AesKeySize);

                return new DerivedKeys(aesKey, hmacKey);

            }
            finally
            { 
              if (derivedBytes != null) Array.Clear(derivedBytes, 0, derivedBytes.Length);
              Array.Clear(combinedBYTES, 0, combinedBYTES.Length);

            }

        }


        #region SALT SECETION
        /// <summary>
        /// Generates a cryptographically secure random salt of the requested size.
        /// </summary>

        public static byte[] SALT_GENERATION(int size_of_Bytes)
        {
            if (size_of_Bytes <= 0) throw new ArgumentOutOfRangeException(nameof(size_of_Bytes), "Salt size must be a positive integer.");
            byte[] salt = new byte[size_of_Bytes];
            RandomNumberGenerator.Fill(salt);
            return salt;
        }


        #endregion

        #region Sealed DerivedKeys Class 
        // ─────────────────────────────────────────────────────────────────────────
        // Simple value holder for the two derived keys.
        // Kept in the same file since it only exists to support KeyDerivation.
        // ─────────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Holds the two keys produced by <see cref="KeyDerivation.Derive"/>.
        /// Dispose or clear these as soon as the cipher operation is complete.
        /// </summary>
        public sealed class DerivedKeys : IDisposable
        {
            public byte[] AesKey { get; private set; }
            public byte[] HmacKey { get; private set; }

            private bool _disposed = false;

            internal DerivedKeys(byte[] aesKey, byte[] hmacKey)
            {
                AesKey = aesKey ?? throw new ArgumentNullException(nameof(aesKey));
                HmacKey = hmacKey ?? throw new ArgumentNullException(nameof(hmacKey));
            }

            /// <summary>
            /// Zeroes both key arrays so they do not linger in managed memory.
            /// Call this in a using() block or finally clause after encryption/decryption.
            /// </summary>
            public void Dispose()
            {
                if (_disposed) return;

                if (AesKey != null) Array.Clear(AesKey, 0, AesKey.Length);
                if (HmacKey != null) Array.Clear(HmacKey, 0, HmacKey.Length);

                AesKey = null;
                HmacKey = null;

                _disposed = true;
            }
        }

        #endregion
    }
}
