﻿using System;
using System.IO;
using K4os.Compression.LZ4;
using K4os.Compression.LZ4.Streams;
using ZstdSharp;

namespace Crp56.Core.Crypto
{
    /// <summary>
    /// Handles compression and decompression for the CRP56 format.
    /// Called by Crp56Cipher before encryption and after decryption.
    ///
    /// Supported modes:
    ///   0x00 = None  (passthrough, no compression)
    ///   0x01 = Zstd  (default, best ratio/speed balance)
    ///   0x02 = LZ4   (fast mode, toggled from UI settings)
    /// </summary>
    /// 

    internal class Crp56_CompressionManager
    {

        /// <summary>
        /// Compresses data using the algorithm specified by compressionMode.
        /// Called by Crp56Cipher before sharding and encrypting.
        /// Returns the original data unchanged if mode is None.
        /// </summary>
        /// 

        #region Compression
        public static byte[] Compress(byte[] data, byte compressionMode)
        {
            if (data == null || data.Length == 0)
            {
                throw new ArgumentException("Data cannot be null or empty.", nameof(data));
            }

            switch (compressionMode)
            {
                case Crp56Constants.CompressionNone:
                    return data;

                case Crp56Constants.CompressionZstd:
                    return CompressZstd(data);

                case Crp56Constants.CompressionLz4:
                    return CompressLz4(data);

                default:
                    throw new NotSupportedException($"Unknown compression mode: 0x{compressionMode:X2}");
            }
        }
        #endregion

        /// <summary>
        /// Decompresses data using the algorithm specified by compressionMode.
        /// Called by Crp56Cipher after shard decryption and reassembly.
        /// Returns the original data unchanged if mode is None.
        /// </summary>

        #region Decompression
        public static byte[] Decompress(byte[] data, byte compressionMode)
        {
            if (data == null || data.Length == 0)
            {
                throw new ArgumentException("Data cannot be null or empty.", nameof(data));
            }

            switch (compressionMode)
            {
                case Crp56Constants.CompressionNone:
                    return data;

                case Crp56Constants.CompressionZstd:
                    return DecompressZstd(data);

                case Crp56Constants.CompressionLz4:
                    return DecompressLz4(data);

                default:
                    throw new NotSupportedException($"Unknown compression mode: 0x{compressionMode:X2}");
            }

        }
        #endregion

        #region LZ4 and Zstd Compression Implementations

        private static byte[] CompressZstd(byte[] data)
        {
            // Level 3 = good ratio/speed balance. Range is 1 (fastest) to 22 (best ratio).
            using (var compressor = new Compressor(level: 3)) {return compressor.Wrap(data).ToArray(); }
        }

        private static byte[] DecompressZstd(byte[] data)
        {
            using (var decompressor = new Decompressor()){ return decompressor.Unwrap(data).ToArray(); }
        }

     

       

        private static byte[] CompressLz4(byte[] data)
        {
            using (var outputStream = new MemoryStream())
            {
                var settings = new LZ4EncoderSettings  { CompressionLevel = LZ4Level.L00_FAST};

                using (var lz4Stream = LZ4Stream.Encode(outputStream, settings, leaveOpen: true)) { lz4Stream.Write(data, 0, data.Length); }

                return outputStream.ToArray();
            }
        }

        private static byte[] DecompressLz4(byte[] data)
        {
            using (var inputStream = new MemoryStream(data))
            using (var lz4Stream = LZ4Stream.Decode(inputStream, leaveOpen: true))
            using (var outputStream = new MemoryStream()) { lz4Stream.CopyTo(outputStream); return outputStream.ToArray(); }
        }

        #endregion
    }
}
