﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace Crp56.Core.Crypto
{
    #region Key Phrase Manager  and Slot randomization 
    public class KeyPhraseManager
    {
        private readonly IReadOnlyList<string> _phrases;

        public KeyPhraseManager(IReadOnlyList<string> phrases)
        {
            if (phrases == null)
            { 
             throw new ArgumentNullException(nameof(phrases), "Phrases list cannot be null.");
            }
            if (phrases.Count != Crp56Constants.KeyPharaseSlots)
            {
                throw new ArgumentException($"Exactly {Crp56Constants.KeyPharaseSlots} base key phrases are required. Got {phrases.Count}.", nameof(phrases));
            }

            for (int x = 0; x < phrases.Count; x++)
            {
                if (string.IsNullOrWhiteSpace(phrases[x]))
                {
                    throw new ArgumentException($"Key phrase at index {x} cannot be null or whitespace.", nameof(phrases));
                }
            }

            _phrases = phrases;
        }

        // Get a key phrase by index (0 to 5) Getter Function 

        public string GetPhrase(int index)
        {
            if (index < 0 || index >= Crp56Constants.KeyPharaseSlots)
            {
                throw new ArgumentOutOfRangeException(nameof(Index), $"Slot index must be between 0 and {Crp56Constants.KeyPharaseSlots - 1}.");
            }

            return _phrases[index];
        }

       
        public int RandomSlotPicker()
        {
            Span<byte> randomBytes = stackalloc byte[1];
            
            RandomNumberGenerator.Fill(randomBytes);

            return randomBytes[0] % Crp56Constants.KeyPharaseSlots;
        }

    }
    #endregion

   
}
