﻿using System;

namespace Crp56.Core.Crypto
{
    #region CRP56 Constants
    /// <summary>
    /// Global constants for the CRP56 format and crypto settings.
    /// </summary>
    public static class Crp56Constants
    {
        // File signature and version 
        public const string Magic = "CRP56";
        public const byte Version = 0x01;

        // Crypto Sizes 
        public const int AesKeySize = 32; // AES-256 key size in bytes
        public const int AesBlockSize = 16; // AES block size in bytes
        public const int DefaultSaltSize = 16; // Default salt size for key derivation in bytes
        public const int DefaultShardPlainSize = 64 * 1024; // Default shard plain size (64KB)

        // PBKDF2 settings 
        public const int Pbkdf2Iterations = 200_000; // Number of iterations for PBKDF2

        // CRP56 format Settings
        public const int KeyPharaseSlots = 6;
        public const string DefaultFileExtension = ".crp56";

        #region Compression Constants

        /// <summary>
        /// No compression. Data is encrypted as-is.
        /// </summary>
        public const byte CompressionNone = 0x00;

        /// <summary>
        /// Zstandard compression. Default mode.
        /// </summary>
        public const byte CompressionZstd = 0x01;

        /// <summary>
        /// LZ4 compression. Fast mode.
        /// </summary>
        public const byte CompressionLz4 = 0x02;

        #endregion
    }
    #endregion

    #region CRP56 Config Class

    public class Crp56Config
    {
        // PlainTXT bytes per shard before encryption (default 64KB)
        public int ShardPlainSize { get; set; } = Crp56Constants.DefaultShardPlainSize;

        // Salt size for key derivation (default 16 bytes)
        public int SaltSize { get; set; } = Crp56Constants.DefaultSaltSize;

        // Number of iterations for PBKDF2 (default 200,000)
        public int KdfIterations { get; set; } = Crp56Constants.Pbkdf2Iterations;

        // HMAC usage flag (default true)
        public bool UseHmac { get; set; } = true;

        #region Compression Settings

        // Compression usage flag (default true = use compression automatically)
        public bool UseCompression { get; set; } = true;

        // Compression mode (default = Zstd)
        public byte CompressionMode { get; set; } = Crp56Constants.CompressionZstd;

        #endregion

        // Validation Function to ensure config values are within acceptable ranges
        public void Validate()
        {
            if (ShardPlainSize <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(ShardPlainSize), "Shard size must be positive.");
            }

            if (SaltSize <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(SaltSize), "Salt size must be positive.");
            }

            if (KdfIterations <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(KdfIterations), "KDF iterations must be positive.");
            }

            if (CompressionMode != Crp56Constants.CompressionNone &&
                CompressionMode != Crp56Constants.CompressionZstd &&
                CompressionMode != Crp56Constants.CompressionLz4)
            {
                throw new ArgumentOutOfRangeException(nameof(CompressionMode), $"Unknown compression mode: 0x{CompressionMode:X2}");
            }
        }
    }
    #endregion
}