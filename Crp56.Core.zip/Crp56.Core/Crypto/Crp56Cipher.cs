﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace Crp56.Core.Crypto
{
    #region Main Encryption Engine for the Carrera 56 Format
    ///<summary>
    /// Responsibilities:
    /// - Uses KeyPhraseManager to select one of 6 base key phrases per encryption.
    /// - Derives AES + HMAC keys from (base phrase + user passphrase + salt) via PBKDF2.
    /// - Builds and parses CRP56 headers.
    /// - Performs polymorphic AES-CBC shard encryption with per-shard IVs.
    /// - Applies Encrypt-then-MAC with HMAC-SHA256 for integrity.
    /// - Optionally compresses plaintext before encryption (Zstd default, LZ4 fast mode).
    /// </summary>

    public class Crp56Cipher
    {

        #region VARS and CONSTRUCTORS
        private readonly KeyPhraseManager keyPhraseManager_HoldingVAR;
        private readonly Crp56Config crp56Config_HoldingVAR;
        private readonly RandomNumberGenerator rng_HoldingVAR = RandomNumberGenerator.Create();

        public Crp56Cipher(Crp56Config config, KeyPhraseManager keyPhraseManager)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }
            crp56Config_HoldingVAR = config;

            if (keyPhraseManager == null)
            {
                throw new ArgumentNullException(nameof(keyPhraseManager));
            }
            keyPhraseManager_HoldingVAR = keyPhraseManager;

            crp56Config_HoldingVAR.Validate();
        }

        #endregion

        #region Public API: Encrypt and Decrypt Methods
        ///<summary>
        /// Where the actual encryption happens. Returns a byte array containing the full CRP56 file content.
        /// </summary>

        public byte[] Encrypt(byte[] plainData, string userPassphrase)
        {
            if (plainData == null || plainData.Length == 0)
            {
                throw new ArgumentException("Plaintext cannot be null or empty.", nameof(plainData));
            }
            if (string.IsNullOrEmpty(userPassphrase))
            {
                throw new ArgumentException("User passphrase cannot be null or empty.", nameof(userPassphrase));
            }

            // 1. Select random base key phrase
            int KeySlotIDX = keyPhraseManager_HoldingVAR.RandomSlotPicker();

            // 2. Generate random salt
            byte[] salt = KeyDerivation.SALT_GENERATION(crp56Config_HoldingVAR.SaltSize);

            // 3. Derive AES and HMAC keys
            string basePhrase = keyPhraseManager_HoldingVAR.GetPhrase(KeySlotIDX);
            using var derivedKeys = KeyDerivation.Derive(basePhrase, userPassphrase, salt, crp56Config_HoldingVAR.KdfIterations);

            // 4. Determine compression mode and compress plainData if enabled
            byte compressionMode = crp56Config_HoldingVAR.UseCompression ? crp56Config_HoldingVAR.CompressionMode: Crp56Constants.CompressionNone;

            byte[] dataToEncrypt = compressionMode != Crp56Constants.CompressionNone ? Crp56_CompressionManager.Compress(plainData, compressionMode): plainData;

            // 5. Shard count calculation (uses compressed size if compression is on)
            ComputeShardLayout(dataToEncrypt.Length, crp56Config_HoldingVAR.ShardPlainSize, out int totalShards, out int lastShardPlainSize);

            // 6. Build header
            var header = new Crp56Header
            {
                Version = Crp56Constants.Version,
                KeySlotIndex = (byte)KeySlotIDX,
                Flags = 0,
                Salt = salt,
                KdfIterations = crp56Config_HoldingVAR.KdfIterations,
                CompressionMode = compressionMode,
                TotalShards = totalShards,
                LastShardSize = lastShardPlainSize
            };
            header.IsHmacEnabled = crp56Config_HoldingVAR.UseHmac;

            return EncryptInternal(dataToEncrypt, header, derivedKeys);
        }

        /// <summary>
        /// Where the actual decryption happens. Takes the full CRP56 file content and returns the decrypted plaintext.
        /// </summary>

        public byte[] Decrypt(byte[] cipherDATA, string userPassphrase)
        {
            if (cipherDATA == null || cipherDATA.Length == 0)
            {
                throw new ArgumentException("Input data cannot be null or empty.", nameof(cipherDATA));
            }
            if (string.IsNullOrEmpty(userPassphrase))
            {
                throw new ArgumentException("User passphrase cannot be null or empty.", nameof(userPassphrase));
            }

            return DecryptInternal(cipherDATA, userPassphrase);
        }

        #endregion

        #region Internal Encryption and Decryption Logic (EncryptInternal and DecryptInternal)

        private byte[] EncryptInternal(byte[] plainData, Crp56Header header, KeyDerivation.DerivedKeys derivedKeys)
        {
            using var aes = Aes.Create();
            aes.Key = derivedKeys.AesKey;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var ms = new MemoryStream();
            using (var writer = new BinaryWriter(ms, System.Text.Encoding.UTF8, leaveOpen: true))
            {
                // 1. Write CRP56 header
                header.WriteTo(writer);

                // 2. Encrypt shards
                int offset = 0;
                int shardSize = crp56Config_HoldingVAR.ShardPlainSize;

                for (int shardIndex = 0; shardIndex < header.TotalShards; shardIndex++)
                {
                    int expectedPlainSize = (shardIndex == header.TotalShards - 1) ? header.LastShardSize : shardSize;

                    // Extract shard plaintext
                    byte[] shardPlain = new byte[expectedPlainSize];
                    Buffer.BlockCopy(plainData, offset, shardPlain, 0, expectedPlainSize);
                    offset += expectedPlainSize;

                    // Generate a fresh IV for this shard
                    byte[] iv = new byte[Crp56Constants.AesBlockSize];
                    rng_HoldingVAR.GetBytes(iv);

                    // Write IV to stream
                    writer.Write(iv);

                    // Encrypt shard and write ciphertext
                    using var encryptor = aes.CreateEncryptor(aes.Key, iv);
                    byte[] shardCipher = encryptor.TransformFinalBlock(shardPlain, 0, shardPlain.Length);
                    writer.Write(shardCipher);
                }
            }

            // 3. Compute and append HMAC tag if enabled
            byte[] withoutHMAC = ms.ToArray();

            if (!header.IsHmacEnabled)
            {
                return withoutHMAC;
            }

            using var hmac = new HMACSHA256(derivedKeys.HmacKey);
            byte[] tag = hmac.ComputeHash(withoutHMAC);

            using var finalStream = new MemoryStream(withoutHMAC.Length + Crp56Header.HmacTagLength);
            finalStream.Write(withoutHMAC, 0, withoutHMAC.Length);
            finalStream.Write(tag, 0, tag.Length);

            return finalStream.ToArray();
        }

        private byte[] DecryptInternal(byte[] cipherDATA, string userPassword)
        {
            using var ms = new MemoryStream(cipherDATA);
            using var reader = new BinaryReader(ms, System.Text.Encoding.UTF8, leaveOpen: true);

            // 1. Read and parse header
            Crp56Header header = Crp56Header.ReadFrom(reader);

            // 2. Split cipher into data without HMAC and the tag (if enabled)
            byte[] cipherWithoutHmac;
            byte[] hmacTag = null;

            if (header.IsHmacEnabled)
            {
                if (cipherDATA.Length < Crp56Header.HmacTagLength)
                {
                    throw new InvalidDataException("Data too short to contain valid HMAC tag.");
                }

                int tagOFFSET = cipherDATA.Length - Crp56Header.HmacTagLength;

                cipherWithoutHmac = new byte[tagOFFSET];
                Buffer.BlockCopy(cipherDATA, 0, cipherWithoutHmac, 0, tagOFFSET);

                hmacTag = new byte[Crp56Header.HmacTagLength];
                Buffer.BlockCopy(cipherDATA, tagOFFSET, hmacTag, 0, Crp56Header.HmacTagLength);
            }
            else
            {
                cipherWithoutHmac = cipherDATA;
            }

            // 3. Derive keys
            string basePhrase = keyPhraseManager_HoldingVAR.GetPhrase(header.KeySlotIndex);
            using var derivedKeys = KeyDerivation.Derive(basePhrase, userPassword, header.Salt, header.KdfIterations);

            // 4. Verify HMAC if enabled
            if (header.IsHmacEnabled)
            {
                using var hmac = new HMACSHA256(derivedKeys.HmacKey);
                byte[] computedTag = hmac.ComputeHash(cipherWithoutHmac);

                if (!ConstantTimeEquals(computedTag, hmacTag))
                {
                    throw new CryptographicException("HMAC verification failed. Data may be corrupted or password is incorrect.");
                }
            }

            // 5. Decrypt shards using AES-CBC with per-shard IVs
            using var aes = Aes.Create();
            aes.Key = derivedKeys.AesKey;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            var plainBytes = new List<byte>(header.TotalShards * crp56Config_HoldingVAR.ShardPlainSize);

            int shardSize = crp56Config_HoldingVAR.ShardPlainSize;
            int blockSize = Crp56Constants.AesBlockSize;

            for (int shardIDX = 0; shardIDX < header.TotalShards; shardIDX++)
            {
                int expectedPlainSIZE = (shardIDX == header.TotalShards - 1) ? header.LastShardSize : shardSize;

                // Read IV
                byte[] iv = reader.ReadBytes(blockSize);
                if (iv.Length != blockSize)
                {
                    throw new InvalidDataException($"Unexpected end of data while reading IV for shard {shardIDX}.");
                }

                int paddedCipherSize = GetPaddedCipherSize(expectedPlainSIZE, blockSize);

                // Read ciphertext
                byte[] shardCipher = reader.ReadBytes(paddedCipherSize);
                if (shardCipher.Length != paddedCipherSize)
                {
                    throw new InvalidDataException($"Unexpected end of data while reading ciphertext for shard {shardIDX}.");
                }

                // Decrypt shard
                using var decryptor = aes.CreateDecryptor(aes.Key, iv);
                byte[] shardPlain = decryptor.TransformFinalBlock(shardCipher, 0, shardCipher.Length);

                if (shardPlain.Length != expectedPlainSIZE)
                {
                    throw new CryptographicException($"Decrypted shard {shardIDX} has unexpected length. Data may be corrupted or password is incorrect.");
                }

                plainBytes.AddRange(shardPlain);
            }

            // 6. Decompress after shard reassembly if compression was used
            byte[] reassembled = plainBytes.ToArray();

            if (header.CompressionMode != Crp56Constants.CompressionNone)
            {
                return  Crp56_CompressionManager.Decompress(reassembled, header.CompressionMode);
            }

            return reassembled;
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Computes the number of shards and the size of the last shard
        /// for a given plaintext length and shard size.
        /// </summary>
        private static void ComputeShardLayout(int totalPlainBytes, int shardPlainSize, out int totalShards, out int lastShardPlainSize)
        {
            if (totalPlainBytes <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(totalPlainBytes), "Plaintext length must be positive.");
            }

            if (shardPlainSize <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(shardPlainSize), "Shard size must be positive.");
            }

            totalShards = (totalPlainBytes + shardPlainSize - 1) / shardPlainSize;
            lastShardPlainSize = totalPlainBytes % shardPlainSize;

            if (lastShardPlainSize == 0) { lastShardPlainSize = shardPlainSize; }
        }

        /// <summary>
        /// Returns AES ciphertext length for a given plaintext size padded to the AES block size.
        /// Matches PKCS7 expectations: even an empty plaintext becomes one full block.
        /// </summary>
        private static int GetPaddedCipherSize(int plainSize, int blockSize)
        {
            if (blockSize <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(blockSize));
            }

            return ((plainSize + blockSize) / blockSize) * blockSize;
        }

        /// <summary>
        /// Compares two byte arrays in constant time to avoid timing side-channels
        /// when verifying HMAC tags.
        /// </summary>
        private static bool ConstantTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) { return false; }

            int diff = 0;
            for (int j = 0; j < a.Length; j++)
            {
                diff |= a[j] ^ b[j];
            }
            return diff == 0;
        }

        #endregion
    }

    #endregion
}